class TestMno:

    def setup(self) -> None:
        pass

    def test_robi(self):
        pass

    def test_gp(self):
        pass

    def test_bn(self):
        pass
