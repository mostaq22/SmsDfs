from fastapi import FastAPI, Request
from models.sms import SmsModel
from repository.sms_repo import SmsRepository

app = FastAPI()


@app.post("/send_sms/")
async def store_sms(sms: SmsModel, request: Request):
    return SmsRepository(data=sms, request=request).store()


@app.get("/sms/{message_id}")
def get_sms_details(message_id: str):
    return SmsRepository.find(message_id)
